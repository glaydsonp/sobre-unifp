
$("#gradient-botao-parceiro").click(function () {
    window.open('investidor', '_blank');
});